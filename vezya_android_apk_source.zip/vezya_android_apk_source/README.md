# Vezya Android APK starter

This Android Studio project packages the existing Vezya responsive HTML prototype in a native Android WebView shell. It can be built into a debug APK using Android Studio or GitHub Actions.

## Important limitation
This is an installable wrapper around the front-end demo. It does **not** provide real user accounts or real-time messages to other devices. The demo chat is local to this app/browser. Use the separate Flutter + Firebase project and configure Firebase to build actual cloud messaging.

## Build an APK with GitHub Actions (phone-friendly route)
1. Create/sign in to a GitHub account and create a **private** repository, e.g. `vezya-android`.
2. Upload the contents of this folder to the repository (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab and allow Actions if prompted.
4. Select **Build Vezya APK** → **Run workflow**.
5. Wait for the workflow to finish successfully. Open that run, scroll to **Artifacts**, and download `vezya-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone, tap `app-debug.apk`, and allow installation from that source if Android asks. Only install APKs you built or trust.

## Build on a computer
Install Android Studio and JDK 17, open this folder as an Android project, allow Gradle sync, then run `assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## App identity
Package ID: `com.vezya.app`. This is a debug build, not Play Store-signed. Before public release, change package ID to one you control and create a proper signed release build.
